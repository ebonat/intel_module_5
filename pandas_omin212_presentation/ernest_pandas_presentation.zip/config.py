
INPUT_FILE_PATH = "input_data.csv"
OUTPUT_FILE_PATH = "output_data.csv"